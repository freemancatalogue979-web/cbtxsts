cd /home/ubuntu/arena/app
git push https://freemancatalogue979-web:ghp_YOUR_TOKEN_HERE@github.com/freemancatalogue979-web/cbtxsts.git arena/01a0d963-cbtxsts
