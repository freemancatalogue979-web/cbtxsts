git push https://<YOUR_GITHUB_USERNAME>:<YOUR_PAT>@github.com/freemancatalogue979-web/cbtxsts.git arena/01a0d963-cbtxsts
