cd /home/ubuntu/arena/app
git push origin arena/01a0d963-cbtxsts
