import { titleOf, themeOf, auraOf, frameOf, portraitOf } from '../lib/cosmetics';
