git config --global credential.helper store
# then push once with the token URL above; it will remember
