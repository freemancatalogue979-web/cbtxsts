# unzip, then:
cd cbtxsts-arena-01a0d963-cbtxsts
git init
git remote add origin https://github.com/freemancatalogue979-web/cbtxsts.git
git checkout -b arena/adapt-01a0d963-vps-fixes
git add -A
git commit -m "Adapt VPS fixes onto 01a0d963: group swipe nav, ranked feedback, chat shared, reaction labels"
git push -u origin arena/adapt-01a0d963-vps-fixes
