if (!started || !ready) return <Splash />;
