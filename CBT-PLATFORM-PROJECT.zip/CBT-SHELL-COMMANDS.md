# CBT platform — every shell / code block, chronological

Each entry is a code block that was pasted into the chat, in the order it happened.

## 2026-10-06 11:05:28 · GROK · chat3 #1  ·  text

```text
API      running  PID 115891  http://localhost:3000
Web      running  PID 115914  http://localhost:5173
```

## 2026-10-06 11:05:28 · GROK · chat3 #1  ·  text

```text
/home/ubuntu/arena/app/
├── README.md
├── start-arena.sh / start-arena.bat   # launchers
├── backend/
│   ├── app/          # main FastAPI app (main.py, models.py, game.py, ws.py, routers/, services/, seed_data/)
│   ├── data/         # SQLite DB
│   ├── scripts/      # verification & demo scripts
│   ├── tests/
│   ├── requirements.txt
│   └── .venv/
├── frontend/
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── vite.config.ts
├── deploy/
│   └── setup-server.sh
└── .arena-run/       # runtime PIDs & logs
```

## 2026-10-06 11:35:22 · GROK · chat3 #5  ·  text

```text
API   running  PID 125513  → port 3000
Web   running  PID 125522  → port 5173
```

## 2026-10-06 11:41:52 · GROK · chat3 #7  ·  ts

```ts
if (!started || !ready) return <Splash />;
```

## 2026-10-07 00:22:01 · GROK · chat1 #249  ·  bash

```bash
cd /home/ubuntu/arena/app
git push origin arena/01a0d963-cbtxsts
```

## 2026-10-07 00:22:01 · GROK · chat1 #249  ·  bash

```bash
git push https://<YOUR_GITHUB_USERNAME>:<YOUR_PAT>@github.com/freemancatalogue979-web/cbtxsts.git arena/01a0d963-cbtxsts
```

## 2026-10-07 00:25:28 · GROK · chat1 #251  ·  bash

```bash
cd /home/ubuntu/arena/app
git push https://freemancatalogue979-web:ghp_YOUR_TOKEN_HERE@github.com/freemancatalogue979-web/cbtxsts.git arena/01a0d963-cbtxsts
```

## 2026-10-07 00:25:28 · GROK · chat1 #251  ·  bash

```bash
git config --global credential.helper store
# then push once with the token URL above; it will remember
```

## 2026-10-07 01:38:10 · GROK · chat1 #267  ·  ts

```ts
import { titleOf, themeOf, auraOf, frameOf, portraitOf } from '../lib/cosmetics';
```

## 2026-10-07 09:11:00 · GROK · chat1 #275  ·  ts

```ts
import { Lottie } from 'lottie-react';
```

## 2026-10-07 09:41:11 · GROK · chat1 #287  ·  text

```text
/home/ubuntu/arena/app/.arena-run/api.log   (~400 KB)
/home/ubuntu/arena/app/.arena-run/web.log   (~40 KB)
```

## 2026-10-16 13:21:45 · GROK · chat1 #489  ·  bash

```bash
# unzip, then:
cd cbtxsts-arena-01a0d963-cbtxsts
git init
git remote add origin https://github.com/freemancatalogue979-web/cbtxsts.git
git checkout -b arena/adapt-01a0d963-vps-fixes
git add -A
git commit -m "Adapt VPS fixes onto 01a0d963: group swipe nav, ranked feedback, chat shared, reaction labels"
git push -u origin arena/adapt-01a0d963-vps-fixes
```

## 2026-10-19 10:24:47 · GROK · chat1 #519  ·  text

```text
================================================================================
WIZ ARENA — SPRITE / ASSET SPEC (Angry Birds–style)
================================================================================
Style: 2D side-ish arena, readable on mobile, warm daylight fantasy/cartoon
Format: PNG or WebP, transparent background where needed
Scale: Design at 2x (retina). Base unit: 1 world unit ≈ 1 px at ref 900×1400

--------------------------------------------------------------------------------
1. WORLD / BACKGROUNDS (parallax layers — stack back → front)
--------------------------------------------------------------------------------
bg_sky_clear.png          900×700   Gradient sky, soft haze (no sun drawn here)
bg_sky_dusk.png           900×700   Optional alternate
bg_sky_night.png          900×700   Night sky (stars can be separate)
bg_sun.png                128×128   Sun disc + soft glow
bg_moon.png               96×96     Moon disc
bg_cloud_01.png           256×128   Fluffy cloud
bg_cloud_02.png           320×140   Bigger cloud
bg_cloud_dark.png         320×140   Storm cloud
bg_hills_far.png          900×400   Distant green/blue ridge (soft)
bg_hills_mid.png          900×450   Mid hills with tree silhouettes optional
bg_ground.png             900×500   Main grass field + path strip baked or separate
bg_path.png               200×500   Dirt path (tileable vertically or full piece)
bg_tree_01.png            128×192   Pine / cartoon tree
bg_tree_02.png            96×160    Smaller tree
bg_rock_01.png            64×40     Ground rock
bg_rock_02.png            48×32     Small rock
bg_grass_tuft.png         32×32     Grass clump (for scatter)
bg_flower.png             24×24     Optional flower

Weather overlays:
fx_rain_drop.png          8×24      Rain streak (or pure particles OK)
fx_lightning.png          64×256    Lightning bolt (flash frame)

--------------------------------------------------------------------------------
2. SLINGSHOT (character prop — critical “feel” asset)
--------------------------------------------------------------------------------
sling_base.png            160×180   Wooden Y body only (no band, no stone)
sling_arm_L.png           48×80     Optional separate left prong if articulated
sling_arm_R.png           48×80     Optional separate right prong
sling_band.png            128×32    Rubber band strip (stretch in code via scale)
sling_pouch.png           48×32     Leather pouch behind ball

OR single sheet:
sling_sheet.png           512×256   Frames: idle | pull_light | pull_mid | pull_max
                          (4 frames × ~128×180 each)

--------------------------------------------------------------------------------
3. PROJECTILE (the “bird”)
--------------------------------------------------------------------------------
ball_idle.png             64×64     Stone / marble / soft orb — clear silhouette
ball_spin_01.png          64×64     Spin frame 1 (or rotate single sprite in code)
ball_spin_02.png          64×64     Spin frame 2
ball_spin_03.png          64×64     Spin frame 3
ball_trail.png            32×32     Soft blur dot for motion trail (optional)

Hit / miss:
fx_impact_dust.png        128×128   4–6 frame strip or single puff
fx_impact_stars.png       128×128   Success sparkles
fx_miss_smoke.png         96×96     Soft fail puff

--------------------------------------------------------------------------------
4. ANSWER TARGETS (must read as WORLD OBJECTS, not UI chips)
--------------------------------------------------------------------------------
Preferred: wooden sign posts planted in grass

sign_post.png             32×96     Wooden stake
sign_board.png            192×128   Blank wood board (grain, nails)
sign_board_A.png          192×128   Board with big “A” badge (or letter in code)
sign_board_B.png          192×128
sign_board_C.png          192×128
sign_board_D.png          192×128

OR one blank board + letter overlays:
letter_A.png … letter_D.png   64×64   Bold painted letters

Optional alternate skins (later seasons):
target_balloon.png        128×160   Balloon with letter
target_crate.png          128×128   Destructible crate (Angry Birds vibe)
target_totem.png          96×160    Stone totem

Idle animation (optional sheet):
sign_idle_sheet.png       768×128   4–6 frames slight sway

Destroy / correct hit:
sign_break_01..04.png     192×128   Board crack / fly apart

--------------------------------------------------------------------------------
5. UI (keep minimal — can stay vector; sprites if you want full polish)
--------------------------------------------------------------------------------
ui_panel.png              512×160   Parchment / wood question panel 9-slice
ui_heart.png              48×48     Life
ui_heart_empty.png        48×48
ui_star.png               48×48     Score
ui_btn.png                196×64    9-slice button
ui_weather_icon_*.png     48×48     clear, clouds, rain, storm, night

--------------------------------------------------------------------------------
6. AUDIO (not sprites, but same “Angry Birds pack” completeness)
--------------------------------------------------------------------------------
sfx_pull.wav              Band stretch
sfx_release.wav           Launch
sfx_whoosh.wav            Flight
sfx_hit_correct.wav       Wood thunk + success chime
sfx_hit_wrong.wav         Dull thud
sfx_miss_ground.wav       Dirt impact
sfx_break.wav             Board smash
bgm_day_loop.ogg          Light outdoor loop
bgm_storm_loop.ogg        Optional

--------------------------------------------------------------------------------
7. NAMING + FOLDER LAYOUT
--------------------------------------------------------------------------------
/assets
  /bg
  /sling
  /ball
  /targets
  /fx
  /ui
  /audio

--------------------------------------------------------------------------------
8. TECHNICAL RULES (so code stays simple)
--------------------------------------------------------------------------------
- Pivot points:
  - Ball: center
  - Sling pouch: center of pouch
  - Sign: bottom-center of post (feet in ground)
- Collision: circle on ball (r≈16–18 @ 64px art); AABB or circle on sign board
- Stretch band in code: scaleX/scaleY or rope segments between fork tips + ball
- Trajectory: code dots (no sprite required) OR use ball_trail.png
- Max atlas size: keep sheets ≤ 2048×2048 for mobile

--------------------------------------------------------------------------------
9. MINIMUM VIABLE PACK (ship first)
--------------------------------------------------------------------------------
MUST HAVE:
  bg_sky_clear, bg_hills_far, bg_hills_mid, bg_ground, bg_path
  bg_tree_01, bg_cloud_01, bg_sun
  sling_base, sling_band, sling_pouch
  ball_idle
  sign_post, sign_board (blank) + letter_A–D OR four painted boards
  fx_impact_dust

NICE SOON:
  Night/storm variants, spin frames, sign break frames, SFX

--------------------------------------------------------------------------------
10. STYLE REFERENCES
--------------------------------------------------------------------------------
- Angry Birds: chunky silhouettes, readable shapes, soft shading, no tiny detail
- Letters on signs: huge, high contrast (colorblind-safe: shape + letter + color)
- World: everything feels “placed on dirt/grass,” not floating UI

================================================================================
END SPEC
================================================================================
```

## 2026-10-19 10:35:56 · GROK · chat1 #523  ·  text

```text
================================================================================
WIZ ARENA — FULL ASSET BIBLE (VERTICAL / PORTRAIT)
================================================================================
ORIENTATION (LOCK THIS IN ART + CODE)
--------------------------------------
• Device: phone portrait (primary). Ref canvas: WIDTH 900 × HEIGHT 1400 (or 1080×1920).
• Camera: fixed side-ish 2.5D “arena slice” — you look slightly down the field.
• Gravity: DOWN ( +Y in screen space if Y grows downward).
• Launch direction: UP the screen (toward negative Y / toward top of phone).
• Sling: BOTTOM-CENTER of playfield. Arms open toward TOP of screen.
• Targets: float/move in the UPPER 55% of the field (above the sling, below the HUD).
• HUD: TOP safe area (question + score). Weather chips: bottom corners, not over sling.
• DO NOT draw sling as if shooting sideways across a landscape phone.
• Art should read: “Angry Birds stood the phone up — bird goes UP at signs in the sky/meadow.”

STYLE
-----
• Chunky cartoon / soft painted (Angry Birds readable silhouettes).
• Warm daylight fantasy. No tiny filigree; mobile-readable at arm length.
• Consistent light: sun from UPPER-LEFT (matches clear weather).
• Transparent PNG/WebP for props; opaque or soft-edge for BG layers.
• Design @2x. Pivot notes below are mandatory for code.

COORDINATE MENTAL MODEL (for artists)
-------------------------------------
Screen top = sky / far hills
Screen middle = target travel band (answer signs)
Screen bottom = ground path + sling “home”
Sling rest ball ≈ 8–12% up from bottom edge of full canvas

================================================================================
1. PARALLAX WORLD (draw as LAYERS — code stacks back → front)
================================================================================
All BG widths match canvas width (900 @1x / 1800 @2x). Heights are minimums.

LAYER 0 — SKY (deepest)
  bg_sky_clear.png     900×900   Soft blue gradient, haze near horizon. NO sun baked in.
  bg_sky_clouds.png    900×900   Overcast grey-blue (rain base).
  bg_sky_storm.png     900×900   Dark slate, heavy mood.
  bg_sky_night.png     900×900   Deep indigo. Stars OPTIONAL here or separate sheet.

LAYER 1 — CELESTIAL (drawn on sky, can animate)
  bg_sun.png           256×256   Disc + soft glow halo. Pivot: center.
  bg_moon.png          192×192   Night disc. Pivot: center.
  bg_star_dot.png      16×16     Optional single star for scatter at night.

LAYER 2 — CLOUDS (scroll slowly L→R or R→L)
  bg_cloud_01.png      512×256   Light fluffy. Transparent. Pivot: center.
  bg_cloud_02.png      640×280   Larger fluff.
  bg_cloud_03.png      400×200   Small accent cloud.
  bg_cloud_dark_01.png 512×256   Storm/grey variant of 01.
  bg_cloud_dark_02.png 640×280   Storm variant of 02.

LAYER 3 — FAR HILLS (no interaction)
  bg_hills_far.png     900×500   Soft distant ridge, cooler green/blue, low contrast.
                                 Bottom of image blends toward mid hills.
  bg_hills_far_night.png 900×500 Night tinted variant OR color-grade in code.

LAYER 4 — MID HILLS / TREE LINE
  bg_hills_mid.png     900×550   Richer green, soft tree silhouettes OK baked OR empty.
  bg_hills_mid_night.png 900×550 Optional.

LAYER 5 — MAIN GROUND (player “stands” here)
  bg_ground.png        900×700   Grass field filling lower half + meadow.
                                 Include subtle path fading toward bottom-center
                                 OR leave path separate (preferred).
  bg_ground_night.png  900×700   Optional darker grass.

LAYER 6 — PATH (align under sling)
  bg_path.png          280×600   Vertical dirt track, wider near bottom, narrow up.
                                 Transparent outside path. Pivot: bottom-center.
                                 Must sit under sling so it feels “planted.”

LAYER 7 — WORLD PROPS (scatter instances)
  bg_tree_01.png       256×384   Tall pine/cartoon tree. Pivot: bottom-center (trunk base).
  bg_tree_02.png       192×320   Medium tree. Pivot: bottom-center.
  bg_tree_03.png       128×224   Small bush-tree. Pivot: bottom-center.
  bg_rock_01.png       128×80    Rock cluster. Pivot: bottom-center.
  bg_rock_02.png       96×64     Small rock. Pivot: bottom-center.
  bg_grass_tuft_01.png 64×64     Grass clump. Pivot: bottom-center.
  bg_grass_tuft_02.png 64×64     Variant.
  bg_flower_01.png     48×48     Optional. Pivot: bottom-center.
  bg_flower_02.png     48×48

WEATHER FX (overlays, not world geometry)
  fx_rain_drop.png     16×48     Soft vertical streak. Or pure code particles.
  fx_rain_splash.png   32×16     Optional ground splash.
  fx_lightning_01.png  128×512   Bolt variant A. Pivot: top-center.
  fx_lightning_02.png  128×512   Bolt variant B.
  fx_fog.png           900×400   Soft mist strip for storm/night (optional).

================================================================================
2. SLINGSHOT — VERTICAL LAUNCHER (BOTTOM OF SCREEN)
================================================================================
CRITICAL ART DIRECTION
• Sling sits BOTTOM-CENTER. Fork tips point UP the screen (toward targets).
• Player pulls ball DOWN / slightly toward self → shoots UP (Angry Birds vertical).
• Draw as 3/4 or pure side wooden Y standing on the path — NOT top-down.
• Separate parts preferred so code can stretch band + keep ball in pouch.

PARTS (recommended)
  sling_base.png       320×360   Full wooden Y: handle + two arms. No band, no ball.
                                 Transparent BG. Pivot: bottom-center of handle
                                 (where it meets the ground/path).
  sling_band.png       256×64    Rubber strip texture (tilable or stretchable).
                                 Code draws two segments: left tip→ball, right tip→ball.
  sling_pouch.png      96×64     Leather cup BEHIND the ball. Pivot: center.
  sling_shadow.png     200×60    Soft ellipse under base (or bake into ground).

OPTIONAL ARTICULATED
  sling_arm_L.png      96×160    Left prong only if you animate flex.
  sling_arm_R.png      96×160    Right prong only.

FRAME SHEET (if you prefer baked poses instead of live stretch)
  sling_sheet.png      1280×360  4 frames side-by-side, each ~320×360:
                                 [0] idle (ball in pouch, band soft)
                                 [1] pull_light
                                 [2] pull_mid
                                 [3] pull_max (max stretch downward)
                                 Same pivot per frame: handle bottom-center.

ANCHOR POINTS (mark in a JSON or tell programmer in pixels @2x)
  fork_tip_L:   pixel on left arm tip (band attaches here)
  fork_tip_R:   pixel on right arm tip
  pouch_center: where ball sits at rest
  ground_contact: bottom of handle

================================================================================
3. BALL / PROJECTILE (the “bird”)
================================================================================
  ball_idle.png        128×128   Clear round stone/marble/soft orb. Thick outline.
                                 Pivot: exact center. Readable at 32px on phone.
  ball_spin_01.png     128×128   Optional spin frame (or rotate idle in code).
  ball_spin_02.png     128×128
  ball_spin_03.png     128×128
  ball_trail.png       64×64     Soft motion smear / glow dot.

IMPACT FX
  fx_impact_dust.png   256×256   Single puff OR 4–6 frame strip horizontal.
  fx_impact_stars.png  256×256   Success sparkles (correct answer).
  fx_miss_smoke.png    192×192   Soft fail / ground hit.
  fx_hit_wood.png      256×256   Optional chips when sign is struck.

================================================================================
4. ANSWER TARGETS — WORLD OBJECTS (NOT UI CHIPS)
================================================================================
They live IN the meadow/sky band, move around, get hit by the ball.
Must feel planted or floating with weight — large enough for vertical aim.

PREFERRED SET: WOODEN SIGN ON A POST
  sign_post.png        64×192    Stake. Pivot: BOTTOM-CENTER (into ground).
  sign_board_blank.png 384×256   Wood board only (grain, nails). Pivot: center.
  sign_board_A.png     384×256   Board with huge “A” + room for short word OR
  sign_board_B.png     384×256   letter only + label drawn in code on blank.
  sign_board_C.png     384×256
  sign_board_D.png     384×256

LETTER OVERLAYS (if using blank board)
  letter_A.png         128×128   Bold painted A (transparent).
  letter_B.png         128×128
  letter_C.png         128×128
  letter_D.png         128×128

COMPOSITE RULE FOR CODE
  Draw order: post (ground) → board (mounted high on post) → letter/ribbon.
  Full sign height roughly 280–320px @2x so hit area is generous on a phone.

IDLE / HIT ANIM
  sign_sway_sheet.png  4–6 frames slight rotation (optional).
  sign_break_01.png    384×256   Crack
  sign_break_02.png    384×256   Split
  sign_break_03.png    384×256   Pieces flying
  sign_break_04.png    384×256   Dust only

COLOR LANGUAGE (for boards if painted)
  A = warm gold/amber wood stain
  B = cool violet/blue stain
  C = green stain
  D = rose/red stain
  + letter shape always present (colorblind safety)

ALTERNATE TARGET SKINS (later)
  target_balloon.png   256×320   Balloon + string, letter on face. Pivot: string bottom.
  target_crate.png     256×256   Wood crate (destructible Angry Birds vibe).
  target_totem.png     192×320   Stone pillar with letter face.

================================================================================
5. UI (CAN BE SPRITES OR VECTOR — SPRITES LISTED FOR FULL POLISH)
================================================================================
Must not fight the vertical layout: question panel under status, above playfield.

  ui_panel_question.png  1024×320   9-slice parchment/wood. Holds question text.
  ui_heart.png           96×96
  ui_heart_empty.png     96×96
  ui_star.png            96×96
  ui_fire_streak.png     96×96      Optional streak icon
  ui_btn_primary.png     392×128    9-slice
  ui_btn_secondary.png   392×128
  ui_weather_clear.png   96×96
  ui_weather_clouds.png  96×96
  ui_weather_rain.png    96×96
  ui_weather_storm.png   96×96
  ui_weather_night.png   96×96
  ui_pause.png           96×96

================================================================================
6. AUDIO
================================================================================
  sfx_pull.wav           Loopable or one-shot stretch tension
  sfx_release.wav        Launch snap
  sfx_whoosh.wav         Flight
  sfx_hit_correct.wav    Wood hit + positive chime
  sfx_hit_wrong.wav      Dull thud
  sfx_miss_ground.wav    Dirt impact
  sfx_break.wav          Board smash
  sfx_ui_tap.wav         Optional
  bgm_day_loop.ogg       Calm outdoor, loops clean
  bgm_storm_loop.ogg     Optional weather swap

================================================================================
7. FOLDER LAYOUT
================================================================================
/assets
  /bg          sky, hills, ground, path, trees, rocks, grass, celestial, clouds
  /sling       base, band, pouch, sheet, shadow
  /ball        idle, spin, trail
  /targets     post, boards, letters, break frames
  /fx          impact, rain, lightning, fog
  /ui          panel, hearts, weather icons, buttons
  /audio       sfx + bgm
  pivots.json  optional: { "sling_base": {"pivot":[0.5,1], "fork_L":[x,y], ...} }

================================================================================
8. PIVOTS & COLLISION (CODE CONTRACT)
================================================================================
Ball
  Pivot: center (0.5, 0.5)
  Collision: circle radius ≈ 0.45 * sprite_width

Sling base
  Pivot: bottom-center of handle (0.5, 1.0)
  Band attach: fork_tip_L / fork_tip_R in local px

Pouch
  Pivot: center; parented to ball while aiming; hidden or stretched on release

Sign (full assembly)
  Post pivot: bottom-center (0.5, 1.0) — “feet in grass”
  Board pivot: center; offset upward on post (~60–70% post height)
  Collision: circle on board center OR AABB of board (prefer circle r≈ board_w*0.4)

Trajectory
  Code-drawn dots OK; optional ball_trail sprites

Atlas
  Prefer separate files first; pack later. Max sheet 2048×2048.

================================================================================
9. VERTICAL SCREEN ZONES (ARTISTS MUST RESPECT)
================================================================================
Y% of 1400-tall canvas (approx):
  0–12%     HUD / question (no critical art)
  12–28%    Sky + sun/moon + far clouds
  28–48%    Far/mid hills
  48–78%    TARGET BAND — all answer signs move only here
  78–90%    Near grass, path, rocks, tree bases
  90–100%   Sling + pull space (ball pulls downward into this band)

Never place important target art in the bottom 20% (finger + sling).
Never place sling art in the top half.

================================================================================
10. MVP SHIP SET (GENERATE / DRAW THESE FIRST)
================================================================================
WORLD
  bg_sky_clear, bg_hills_far, bg_hills_mid, bg_ground, bg_path
  bg_sun, bg_cloud_01, bg_tree_01, bg_grass_tuft_01, bg_rock_01

SLING
  sling_base, sling_band, sling_pouch

BALL
  ball_idle
  fx_impact_dust

TARGETS
  sign_post, sign_board_blank
  letter_A, letter_B, letter_C, letter_D
  (OR sign_board_A..D painted)

THEN
  Night/storm skies, dark clouds, break frames, spin frames, SFX

================================================================================
11. PROMPT HINTS (Scenario / AI) — ALWAYS MENTION VERTICAL + UPWARD SLING
================================================================================
Common suffix:
  "2D mobile game sprite, chunky cartoon, Angry Birds readability, soft shading,
   transparent background, no UI text, centered subject, high contrast silhouette"

Sling:
  "wooden Y slingshot viewed from the front, fork arms pointing UP, handle at
   bottom, game prop sprite, isolated, transparent background"

Ball:
  "round stone marble projectile game sprite, centered, transparent background"

Sign:
  "wooden sign board on a stake planted in ground, large letter A painted,
   mobile game prop, transparent background, bottom of stake at image bottom"

Hill layer:
  "wide soft rolling green hills layer for 2D game parallax, seamless left-right,
   no characters, no UI"

================================================================================
END BIBLE — VERTICAL WIZ ARENA
================================================================================
```

## 2026-10-20 08:03:55 · GROK · chat1 #544  ·  text

```text
================================================================================
WIZ ARENA — WORLD ASSETS (VERTICAL)
================================================================================
Playfield: portrait ~900×1400 · sling bottom · targets mid · sky top
Style: chunky cartoon, readable on phone, soft shading (Angry Birds–readable)

--------------------------------------------------------------------------------
1. SKY / ATMOSPHERE (full-width layers)
--------------------------------------------------------------------------------
bg_sky_clear.png      900×700+   Soft blue gradient, light haze (no sun baked in)
bg_sky_clouds.png     900×700+   Overcast blue-grey
bg_sky_storm.png      900×700+   Dark slate storm sky
bg_sky_night.png      900×700+   Deep indigo / night

bg_sun.png            128–256²   Sun disc + soft glow (clear / mild weather)
bg_moon.png           96–192²    Moon disc (night)
bg_star_dot.png       8–16²      Optional single star for night scatter

bg_cloud_01.png       ~256×128   Light fluffy cloud
bg_cloud_02.png       ~320×140   Larger light cloud
bg_cloud_dark_01.png  ~256×128   Storm / rain cloud
bg_cloud_dark_02.png  ~320×140   Heavy storm cloud

--------------------------------------------------------------------------------
2. TERRAIN (parallax hills → ground under the sling)
--------------------------------------------------------------------------------
bg_hills_far.png      900×400    Distant soft ridge (cooler green/blue)
bg_hills_mid.png      900×450    Mid hills (richer green)
bg_ground.png         900×500    Main grass field (lower half of screen)
bg_path.png           ~200×500   Dirt path under sling (bottom-center, wider at feet)

Optional if not drawn in code:
bg_ground_night.png   900×500    Darker grass tint for night
bg_hills_*_night.png             Night variants of hill layers

--------------------------------------------------------------------------------
3. WORLD PROPS (planted on ground — pivot BOTTOM-CENTER)
--------------------------------------------------------------------------------
You already have some of these from Cropio; keep the same style.

tree_pine.png         ~128×192   Tall pine / evergreen
tree_round.png        ~128×160   Round canopy tree
tree_tall.png         ~96×160    Medium/tall secondary tree
bush.png              ~96×96     Low bush (optional)

rock_01.png           ~64×48     Medium rock
rock_02.png           ~48×32     Small rock

grass_tuft.png        ~32×32     Grass clump (scatter along path)
flower.png            ~24×24     Optional accent

Placement zones (feet on grass line ~y 1100–1200):
  Left ridge:  pine + tall + rock
  Path flanks: rocks left/right of dirt path
  Right ridge: round tree + rock + tall tree

--------------------------------------------------------------------------------
4. WEATHER FX (overlays)
--------------------------------------------------------------------------------
fx_rain_drop.png      8×24       Rain streak (or pure particles)
fx_rain_splash.png    32×16      Optional ground splash
fx_lightning.png      64×256     Lightning bolt flash
fx_fog.png            900×300    Soft mist strip (storm/night, optional)

--------------------------------------------------------------------------------
5. SLING + PROJECTILE (not “sky” but part of the world stage)
--------------------------------------------------------------------------------
sling_base.png        ~160×180   Wooden Y, arms pointing UP, handle at bottom
sling_band.png        stretch    Red rubber (or draw in code)
sling_pouch.png       ~48×32     Optional pouch

ball_idle.png         ~64×64     Stone orb
ball_spin_*.png       ~64×64     Flight frames (optional)
ball_crumble_0..5     sheet      Impact / fail (you already have these)

--------------------------------------------------------------------------------
6. ANSWER TARGETS (live in the mid “arena band”)
--------------------------------------------------------------------------------
letter_block_A..D     idle       Wooden/stone A–D blocks
letter_crumble_A..D   0..5       Break → dust (you already have these)

Pivot: center · live roughly y 380–780 so they sit above the ground props

--------------------------------------------------------------------------------
7. WHAT YOU CAN SKIP (code can fake it)
--------------------------------------------------------------------------------
• Sky gradients, sun rays, star dots, rain streaks, lightning
• Grass sway, simple path ruts
• Band stretch lines between fork tips and ball

Prefer real art for: hills, ground, path, trees, rocks, sling, ball, letter blocks.

--------------------------------------------------------------------------------
8. MINIMUM WORLD PACK (ship first)
--------------------------------------------------------------------------------
MUST:
  sky (clear + night or clear + storm)
  sun OR moon
  1–2 cloud types
  hills far + mid (or one strong ground plate)
  ground + path
  2 trees + 1 rock
  sling + ball idle
  A–D idle blocks

NICE:
  full 4 skies, dark clouds, lightning, crumble sheets, extra trees/rocks

--------------------------------------------------------------------------------
9. TECHNICAL NOTES
--------------------------------------------------------------------------------
• Transparent PNG/WebP for props; opaque OK for sky/hills
• Prop pivots: bottom-center (trees, rocks, sling handle)
• Ball / letters: center pivot
• Design @2x for mobile; keep silhouettes chunky
• World must read in all weathers: clear, clouds, rain, storm, night

================================================================================
END — WORLD ASSET LIST
================================================================================
```

## 2026-10-20 08:09:41 · GROK · chat1 #550  ·  text

```text
================================================================================
BG = LAYERED PIECES (not one photo)
================================================================================
Draw order: back → front

1. SKY PLATES (full width, top half)
   bg_sky_clear.png       Soft blue gradient plate
   bg_sky_clouds.png      Grey-blue overcast plate
   bg_sky_storm.png       Dark storm plate
   bg_sky_night.png       Night plate

   Size idea: ~900×700 (or taller). No sun/moon baked in.

2. CELESTIAL (small, drawn on sky)
   bg_sun.png             Disc + glow
   bg_moon.png            Disc
   (stars can be code dots)

3. CLOUDS (separate sprites, scroll)
   bg_cloud_light_01.png
   bg_cloud_light_02.png
   bg_cloud_dark_01.png
   bg_cloud_dark_02.png

4. HILLS (wide strips, mid screen)
   bg_hills_far.png       Soft distant ridge
   bg_hills_mid.png       Closer, richer green

   Size idea: ~900×400 each. Seamless-ish left–right.

5. GROUND (bottom)
   bg_ground.png          Main grass fill under hills
   bg_path.png            Dirt path under the sling only

6. WEATHER OVERLAYS (optional)
   rain streaks / lightning / fog — sprites or code

================================================================================
MINIMUM TO “BUILD” A BG WITHOUT ONE BIG IMAGE
================================================================================
• 1 sky plate (clear is enough to start)
• sun
• 1 light cloud
• 1 hills strip (or far + mid)
• ground grass
• path under sling

Then add storm/night skies + dark clouds when you want weather variety.

================================================================================
WHAT WE ARE NOT ASKING FOR
================================================================================
✗ One 1080×1920 finished screenshot of the whole scene
✗ UI, letters, ball, sling (those are separate)

================================================================================
```
