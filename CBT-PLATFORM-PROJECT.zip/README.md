# CBT Platform — one merged, date-sorted project from 3 Grok chats

**Scope:** the **Absolute Genesis / CBT quiz platform** only.
`arena/01a0d963-cbtxsts` · app path `/home/ubuntu/arena/app` · plus the **Wiz Arena** slingshot game prototype.

---

## The one file you want

**[`CBT-HISTORY.md`](CBT-HISTORY.md)** — 235 messages from all three chats, merged into one chronological timeline.
Your prompt → Grok's answer → the bash/tool output, in the exact order it happened, with every code block inline.

| | |
|---|---|
| Messages kept | **235** (of 832 across the 3 chats) |
| Code blocks | **16** (each also saved as its own file in `code-blocks/`) |
| Active days | **10** — 6, 7, 10, 12, 13, 16, 19, 20, 27 Oct + 1 Nov 2026 |
| Source chats | chat1 (207 kept) · chat2 (8 kept) · chat3 (all 20) |

## The rest

| File | What it is |
|---|---|
| `CBT-CODE.md` | All 16 code blocks, indexed by timestamp + saved file name. |
| `CBT-SHELL-COMMANDS.md` | Every code block again, in pure chronological order — easy to read as a command log. |
| `code-blocks/` | Each code block as its own file: `NNN-YYYYMMDD-HHMMSS-chatN-msgN.ext`. |
| `EXCLUDED.md` | What was filtered out and where to find it anyway. |
| `_cbt_records.json`, `_code_rows.json` | Machine-readable data (every kept message / every code block). |

## What was excluded — and why

| Excluded | Why | Where it still lives |
|---|---|---|
| **9 CLOVER** — MLBB team-ops app (`arena/ef137255-cbtxsts`): scrims, tournaments, draft lab, heroes, Rone/MLBB sync, gear, Map Lab, WhatsApp push | Different product, same repo | `../output2/` (chat #2 extract, full) |
| **Fixiis** — browser streaming / DOM capture, banks, SeleniumBase | Different product entirely | `../output/` (chat #1 extract, full) |
| Infra — cloud credits, RDP desktops, Kimi bot, VPS provisioning | Not project work | `../output/full-transcript.md` |
| The 16 Oct "9 Clover repo status" thread + 27 Oct recap | Explicitly 9 CLOVER, per your instruction | `../output/ARENA-MASTER-SUMMARY.md` §1–§2 |

## How the CBT/9-Clover split was decided

The same VPS hosted **both** apps and you were switching between them by path, so the split isn't guesswork —
it was resolved from hard evidence inside the messages:

- **CBT** — anything naming `/home/ubuntu/arena/app`, `arena/01a0d963-cbtxsts`, or Absolute Genesis / CBT-specific
  vocabulary (study groups, courses, CBT papers, AI Tutor, teacher chat, friends chat, profile cosmetics, ranked
  teams, world map, Global Challenges, Wiz Arena).
- **9 CLOVER** — anything naming `/home/ubuntu/arena/ef137255`, `arena/ef137255-cbtxsts`, `9clover.gg`, `clover.db`,
  or MLBB vocabulary (scrims, drafts, heroes, Rone, gear, Map Lab, tournaments).
- Ambiguous one-liners ("restart the project", "update files") were resolved to whichever app the surrounding
  session was anchored to, using the explicit path/branch mentions in the neighbouring messages.

## Coverage by day

| Date | What happened |
|---|---|
| **6 Oct** | Connect + pull `01a0d963`; LAW course purge; demo-seed fix; mobile long-press; fonts; teacher-chat parity; global challenges; **chat #3**: hooks-order bugs, World Map revamp, Global Challenges → removed, Study Lab + CBT paper rebuild (`AnswerTile`) |
| **7 Oct** | Commit `8e91788` + PAT push; Friends chat parity; Study Lab revamp; profile modal; `toggleSkin`/`currentSkin`/`auraOf`/`PROFILE_BANNERS` import fixes; Lottie themes; rank & achievement banners; profile scroll bug; login logs; device-based fonts; profile layout splits; multiplayer duel rooms; project restart |
| **10 Oct** | Absolute Genesis start + fresh cloudflared tunnel (chat #2) |
| **12 Oct** | Light-theme overhaul: hardcoded dark colours removed, PWA screenshot updated, all chats full-screen on mobile, quiz question card de-glassed |
| **13 Oct** | Full-screen chats (Friends/AI Tutor/Teacher), iPad splash watchdog → production `vite preview`, AI Tutor chat list z-index, PWA screenshots, reaction-menu double emoji, **shared chat module** extracted, swipeable group nav, `chatBubbleClass` import, ranked/multiplayer bug fixes, the Linode `billing_suspension` loss |
| **16 Oct** | The `8e91788` audit: what's on GitHub vs what's missing → **7-file adaptation table** onto `arena/adapt-01a0d963-vps-fixes` |
| **19–20 Oct** | **Wiz Arena**: quiz → game. Slingshot demo → physics → endless mode → moving targets → SVG sprites → canvas weather world → your sprite sheet + Cropio packs → 4 asset bibles → vertical layout → premium UI → code-drawn ground/sun/rain |
| **27 Oct – 1 Nov** | The 9 Clover repo status (excluded), then the Nov 1 thread: *"tell me everything you worked on Absolute Genesis the quiz app"* → Grok refuses → and what the latest quiz-arena branch is |

## Extraction method

Grok share pages don't embed the transcript. Payload comes from
`GET https://grok.com/rest/app-chat/share_links/<id>?useChunk=true` — Cloudflare blocks datacenter IPs, so it was
pulled through **`proxy.corsfix.com` with an `Origin: http://localhost:3000` header** (it rejects other origins).
Recovered: chat1 = 9.4 MB / 626 records, chat2 = 3.57 MB / 208 records, chat3 = 583 KB / 20 records.
Human turns come from `inputChunks`, Grok's answers/reasoning/tool calls from `outputChunks`.
