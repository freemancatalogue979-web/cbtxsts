# Excluded from the CBT project — and where to find it

Everything below was filtered out of `CBT-HISTORY.md` because it isn't the **CBT / Absolute Genesis quiz platform**.
Nothing was lost — each source chat was extracted in full and is preserved.

## 1. 9 CLOVER — the MLBB team-ops app (`arena/ef137255-cbtxsts`)

A **different product that shares the `cbtxsts` repo** with the CBT app. You were running both on the same VPS and
switching between them by directory, which is exactly why this had to be filtered rather than assumed.

What's in it: scrims, tournaments (BO1/BO3/BO5), the Draft Lab + pro draft board, match reviews, heroes roster
(135 seeded), Rone / `arena.rone.dev` MLBB sync (hero skills, builds, emblems, spells), Land of Dawn Map Lab with
free pan/zoom, strategy notes + playbooks, training evidence → coach approval, WhatsApp-style chat UI, the
dark/light + 12-accent theme system, `LineupBoard`, Web Push / VAPID, the new clover logo + PWA icon set, and the
**Oct 16 rebuild checklist** Grok wrote the day the VPS died.

📁 Full extraction: **`../output2/`** — `ARENA-MASTER-SUMMARY.md` (the rebuild checklist is §2), `full-transcript.md`,
`code-archive.md`, `arena-extract.md`, `code-blocks/`, `arena-file-inventory.md`, `image-manifest.md`.

Two chat-#2 messages that ARE about the CBT app were kept in the CBT project because they are:
`chat2` #18–#21 (switching the box over to Absolute Genesis at `/home/ubuntu/arena/app` + the `git stash` recovery
of your overwritten CBT files — `PlayerCard.tsx`, `AppShell.tsx`, `ThemeBannerFX.tsx`, `ThemeLottie.tsx`, the
Friends/Profile/Ranks/Study panels, `backend/app/routers/rooms.py`, `social.py`) and #158–#161 (starting Absolute
Genesis + a new cloudflared tunnel, and locating the latest AG checkout).

## 2. Fixiis — browser streaming / DOM capture

`api.py`, `browser_manager.py`, `dom_capture.py`, `sb_backend.py`, `webrtc_stream.py`, `stealth_advanced.py`,
`Admin.html`, `client.html`, the bank-dom-capture pipeline (164 stability hosts, Citi/Chase/Fifth Third), the
site allowlist + admin override, capture-speed work, and the `Fixiis-recovery.zip` package.

📁 Full extraction: **`../output/`** — `ARENA-MASTER-SUMMARY.md` §8, `full-transcript.md`, `code-archive.md`.

## 3. Generic infrastructure

Cloud-credit research, RDP/VNC desktop installs (XFCE/Cinnamon/Budgie/Cosmic), the Kimi web-UI bot, VPS
provisioning, and Linode billing.

📁 Still in **`../output/full-transcript.md`** (chat #1) and **`../output2/full-transcript.md`** (chat #2).

## 4. The 27 Oct "9 Clover repo status" thread + 16 Oct recap (chat #1 #580–#598)

You asked *"9 clover project do you have the repo link?"* and Grok answered with the repo state and a recap of the
9 Clover work — excluded because it is the other product.

But the **Nov 1 thread that follows it is in the CBT project**, because that one is explicitly about Absolute
Genesis: *"In a .txt file tell me everything you worked on absolute Genesis the quiz app"* → Grok's refusal, your
pushback, and Grok's answer to *"What is the latest quiz arena branch"*.

## 5. One thing to note about the excluded thread

Grok's 16 Oct recap (#194 in chat #2) is the single best rebuild checklist in any of the three chats — but it covers
**9 CLOVER**, so per your instruction it is not in the CBT zip. If you ever rebuild *that* app, pull
`../output2/ARENA-MASTER-SUMMARY.md` §2 rather than re-reading 200 messages.
