/**
 * Practice arena + boss battles.
 *
 * Score, combos, lives and boss damage are all computed by the server; this
 * screen only ever renders what the API returns and sends the tapped option.
 */
import {
  AlertTriangle,
  Bomb,
  Flame,
  Gauge,
  Heart,
  Play,
  Shield,
  Skull,
  Snowflake,
  Sparkles,
  Swords,
  Timer,
  Trophy,
  Zap,
} from 'lucide-react';
import {AnimatePresence, motion} from 'motion/react';
import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import Character from '../components/Character';
import {AnswerFeedback, AnswerTile, ComboMeter, Hearts} from '../components/GameQuestion';
import {Button, Card, Chip, EmptyState, ProgressBar, SectionHeading, Segmented, Skeleton} from '../components/ui';
import {api} from '../lib/api';
import {HAPTICS} from '../lib/haptics';
import {sfx} from '../lib/sfx';
import {useSession} from '../store/session';

type QuestionPayload = {
  id: number;
  text: string;
  options: Record<string, string>;
  display_order: string[];
  explanation?: string;
  hint?: string;
  difficulty?: string;
  topic?: string;
  media?: {question_image?: string; audio?: string};
};

type ModeRow = {key: string; label: string; size: number; lives: number; seconds: number; xp: number; best: number; played: number};
type Powerup = {key: string; name: string; blurb: string; icon: string};

const POWERUP_ICON: Record<string, typeof Zap> = {
  scissors: Bomb,
  lightbulb: Sparkles,
  snowflake: Snowflake,
  shield: Shield,
  'rotate-ccw': Timer,
  zap: Zap,
  flame: Flame,
};

function OptionButton({
  label,
  text,
  state,
  hidden,
  disabled,
  onClick,
}: {
  label: string;
  text: string;
  state: 'idle' | 'correct' | 'wrong';
  hidden: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  if (hidden) {
    return (
      <div className="sunken flex min-w-0 items-center gap-2.5 px-3 py-2.5 opacity-45">
        <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-white/8 text-[0.74rem] font-black text-mist-500">{label}</span>
        <span className="text-[0.84rem] font-semibold text-mist-500">Removed by 50/50</span>
      </div>
    );
  }
  return (
    <AnswerTile
      letter={label}
      text={text}
      state={state === 'correct' ? 'correct' : state === 'wrong' ? 'wrong' : 'idle'}
      disabled={disabled}
      onPick={onClick}
    />
  );
}

/* ------------------------------------------------------------------ practice */
function PracticeRun({mode, label, onExit}: {mode: string; label: string; onExit: () => void}) {
  const {toast, pushRewards, setProfile, profile} = useSession();
  const [run, setRun] = useState<{
    token: string;
    lives: number;
    seconds: number;
    questions: QuestionPayload[];
    powerups: Record<string, number>;
  } | null>(null);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [lives, setLives] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{correct: boolean; expected?: string; expected_label?: string | null; explanation?: string} | null>(null);
  const [hidden, setHidden] = useState<string[]>([]);
  const [powerups, setPowerups] = useState<Record<string, number>>({});
  const [risk, setRisk] = useState(false);
  const [remaining, setRemaining] = useState(0);
  const [frozen, setFrozen] = useState(0);
  const [summary, setSummary] = useState<Record<string, unknown> | null>(null);
  const askedAt = useRef(Date.now());

  useEffect(() => {
    api.arena
      .startPractice({mode, size: 0})
      .then((payload) => {
        const data = payload as unknown as {token: string; lives: number; seconds: number; questions: QuestionPayload[]; powerups: Record<string, number>};
        setRun(data);
        setLives(data.lives);
        setPowerups(data.powerups ?? {});
        setRemaining(data.seconds);
        askedAt.current = Date.now();
      })
      .catch((error: Error) => toast('error', 'Could not start', error.message));
  }, [mode, toast]);

  useEffect(() => {
    if (!run || !run.seconds || summary) return undefined;
    const timer = window.setInterval(() => {
      setFrozen((value) => {
        if (value > 0) return value - 1;
        setRemaining((seconds) => Math.max(0, seconds - 1));
        return 0;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [run, summary]);

  const question = run?.questions[index];
  const finished = Boolean(summary);

  const finish = useCallback(
    async (elapsedMs: number) => {
      if (!run) return;
      try {
        const result = await api.arena.finishPractice(run.token, elapsedMs);
        setSummary(result as unknown as Record<string, unknown>);
        const rewards = (result as {rewards?: unknown[]}).rewards ?? [];
        if (rewards.length) pushRewards(rewards as never);
        if ((result as {profile?: unknown}).profile) setProfile((result as {profile: never}).profile);
        HAPTICS.win();
        sfx.play('win');
      } catch (error) {
        toast('error', 'Could not finish the run', (error as Error).message);
      }
    },
    [pushRewards, run, setProfile, toast],
  );

  // Time attack: the server also refuses late answers, so the clock is honest.
  useEffect(() => {
    if (!run || !run.seconds || summary || remaining > 0) return;
    void finish((Date.now() - askedAt.current) * 0 + run.questions.length * 1000);
  }, [run, remaining, summary, finish]);

  const answer = async (label: string) => {
    if (!run || !question || picked || feedback) return;
    setPicked(label);
    try {
      const result = await api.arena.answerPractice({
        token: run.token,
        question_id: question.id,
        selected: label,
        elapsed_ms: Date.now() - askedAt.current,
        risk,
      });
      const data = result as unknown as {correct: boolean; expected: string; expected_label: string | null; explanation: string; score: number; combo: number; lives: number; finished: boolean; powerups: Record<string, number>; max_combo?: number};
      setFeedback({correct: data.correct, expected: data.expected, expected_label: data.expected_label, explanation: data.explanation});
      setScore(data.score);
      setCombo(data.combo);
      setLives(data.lives);
      setPowerups(data.powerups ?? powerups);
      if (data.correct) {
        sfx.play('correct');
        HAPTICS.correct();
      } else {
        sfx.play('wrong');
        HAPTICS.wrong();
      }
      if (data.finished) {
        window.setTimeout(() => void finish(Date.now() - askedAt.current), 900);
      }
    } catch (error) {
      setPicked(null);
      toast('error', 'Answer not saved', (error as Error).message);
    }
  };

  const next = () => {
    setFeedback(null);
    setPicked(null);
    setHidden([]);
    setIndex((value) => value + 1);
    askedAt.current = Date.now();
  };

  const usePowerup = async (key: string) => {
    if (!run || !question) return;
    try {
      const result = await api.arena.usePowerup(run.token, key, question.id);
      const data = result as unknown as {hidden?: string[]; hint?: string; freeze_seconds?: number; powerups?: Record<string, number>};
      if (data.powerups) setPowerups(data.powerups);
      if (data.hidden) setHidden(data.hidden);
      if (data.freeze_seconds) setFrozen(data.freeze_seconds);
      if (data.hint) setFeedback((current) => ({...(current ?? {correct: false}), explanation: data.hint}));
    } catch (error) {
      toast('error', 'Power-up failed', (error as Error).message);
    }
  };

  if (finished) {
    const correct = Number(summary?.correct ?? 0);
    const total = Number(summary?.total ?? 0);
    return (
      <Card className="relative overflow-hidden p-5 text-center">
        <div className="pointer-events-none absolute -top-24 left-1/2 size-56 -translate-x-1/2 rounded-full bg-nova-600/20 blur-3xl" />
        <div className="relative mx-auto grid size-16 place-items-center rounded-3xl brand-gradient text-white">
          {summary?.perfect ? <Trophy className="size-7" /> : <Gauge className="size-7" />}
        </div>
        <h3 className="relative mt-3 text-lg font-black text-mist-50">
          {summary?.perfect ? 'Perfect run!' : `${correct}/${total} correct`}
        </h3>
        <p className="relative mt-1 text-[0.84rem] font-medium text-mist-500">
          {label} · {Number(summary?.score ?? 0)} points · best combo {Number(summary?.max_combo ?? 0)}x
        </p>
        <div className="relative mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Chip className="border-white/12 bg-white/6 text-mist-300">+{Number(summary?.xp ?? 0)} XP</Chip>
          <Chip className="border-gold-500/25 bg-gold-500/10 text-gold-200">+{Number(summary?.coins ?? 0)} coins</Chip>
          <Chip className="border-white/12 bg-white/6 text-mist-300">best {Number(summary?.best ?? 0)}</Chip>
          <Chip className="border-nova-500/25 bg-nova-500/10 text-nova-200">{summary?.new_best ? 'New personal best' : 'Keep pushing'}</Chip>
        </div>
        <div className="relative mt-5 flex flex-wrap justify-center gap-2">
          <Button variant="primary" onClick={onExit}>Back to modes</Button>
        </div>
      </Card>
    );
  }

  if (!run || !question) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-12 w-full" />
      </div>
    );
  }

  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Chip className="border-white/12 bg-white/6 text-mist-300">{label}</Chip>
        <Chip className="border-nova-500/25 bg-nova-500/10 text-nova-200" icon={<Zap className="size-3.5" />}>
          {score} pts
        </Chip>
        <ComboMeter combo={combo} />
        {run.lives > 0 && (
          <span className="sunken flex items-center gap-1.5 px-2.5 py-1">
            <Hearts value={Math.max(0, lives)} max={run.lives} />
          </span>
        )}
        {run.seconds > 0 && (
          <Chip className="border-white/12 bg-white/6 text-mist-300" icon={<Timer className="size-3.5" />}>
            {frozen > 0 ? `frozen ${frozen}s` : `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`}
          </Chip>
        )}
        <Chip className="ml-auto border-white/12 bg-white/6 text-mist-400">
          {index + 1}/{run.questions.length}
        </Chip>
      </div>

      <ProgressBar value={((index + (feedback ? 1 : 0)) / run.questions.length) * 100} />

      <Card className="relative overflow-hidden p-4 sm:p-5">
        {/* The hero watches the drill: cheering a hit, wincing a miss. */}
        <Character
          mood={feedback ? (feedback.correct ? 'cheer' : 'sad') : 'idle'}
          size={54}
          tone="day"
          className="absolute -top-2 right-1 hidden opacity-95 sm:block"
          label="Arena hero"
        />
        <div className="flex items-center gap-2">
          <Chip className="border-white/12 bg-white/6 text-mist-400">{question.topic || 'Practice'}</Chip>
          <Chip className="border-white/12 bg-white/6 text-mist-400">{question.difficulty || 'medium'}</Chip>
          <button
            type="button"
            onClick={() => setRisk((value) => !value)}
            className={`ml-auto rounded-xl border px-2.5 py-1 text-[0.7rem] font-extrabold transition-colors ${
              risk ? 'border-gold-500/40 bg-gold-500/15 text-gold-200' : 'border-white/12 bg-white/6 text-mist-400'
            }`}
            title="Risk mode: double points for a correct answer, −50 for a miss"
          >
            RISK
          </button>
        </div>
        {question.media?.question_image && (
          <img src={question.media.question_image} alt="" className="mt-3 max-h-52 w-full rounded-2xl object-contain" />
        )}
        <p className="mt-3 text-[0.98rem] leading-relaxed font-extrabold text-mist-50">{question.text}</p>
        {question.media?.audio && <audio className="mt-3 w-full" controls src={question.media.audio} />}

        <div className="mt-4 grid gap-2">
          {question.display_order.map((key, position) => {
            const label = 'ABCD'[position] ?? '';
            const state: 'idle' | 'correct' | 'wrong' =
              feedback && feedback.expected_label === label
                ? 'correct'
                : picked === label && feedback && !feedback.correct
                  ? 'wrong'
                  : 'idle';
            return (
              <OptionButton
                key={key}
                label={label}
                text={question.options[label] ?? ''}
                state={state}
                hidden={hidden.includes(key)}
                disabled={Boolean(picked)}
                onClick={() => void answer(label)}
              />
            );
          })}
        </div>

        <AnimatePresence>
          {feedback && (
            <motion.div initial={{opacity: 0, y: 8}} animate={{opacity: 1, y: 0}} exit={{opacity: 0}} className="mt-4">
              <AnswerFeedback
                cosmetics={profile?.cosmetics}
                correct={feedback.correct}
                chosen={picked}
                answer={feedback.expected_label ?? feedback.expected ?? null}
                combo={combo}
                note={feedback.explanation || undefined}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
        {Object.entries(powerups).map(([key, count]) => {
          const Icon = POWERUP_ICON[key] ?? Zap;
          return (
            <button
              key={key}
              disabled={count <= 0 || Boolean(feedback)}
              onClick={() => void usePowerup(key)}
              className="flex shrink-0 items-center gap-1.5 rounded-2xl border border-white/12 bg-ink-900/70 px-3 py-2 text-[0.74rem] font-bold text-mist-300 disabled:opacity-40"
            >
              <Icon className="size-3.5" />
              {key.replace('_', ' ')}
              <span className="text-mist-500">×{count}</span>
            </button>
          );
        })}
      </div>

      <div className="flex gap-2">
        {feedback ? (
          <Button variant="primary" className="flex-1" onClick={next} disabled={index + 1 >= run.questions.length && !summary}>
            {index + 1 >= run.questions.length ? 'Finish run' : 'Next question'}
          </Button>
        ) : (
          <Button variant="ghost" className="flex-1" onClick={() => void finish((index + 1) * 1000)}>
            End run early
          </Button>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- boss */
function BossFight({bossKey, onExit}: {bossKey: string; onExit: () => void}) {
  const {toast, pushRewards} = useSession();
  const [fight, setFight] = useState<{run_id: number; boss: {name: string; hp_max: number; lives: number}; questions: QuestionPayload[]} | null>(null);
  const [index, setIndex] = useState(0);
  const [hp, setHp] = useState(0);
  const [damage, setDamage] = useState(0);
  const [combo, setCombo] = useState(0);
  const [lives, setLives] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{correct: boolean; damage: number; crit: boolean; expected?: string} | null>(null);
  const [over, setOver] = useState<{won: boolean; rewards?: unknown[]} | null>(null);
  const askedAt = useRef(Date.now());

  useEffect(() => {
    api.arena
      .startBoss({boss_key: bossKey, size: 0})
      .then((payload) => {
        const data = payload as unknown as {run_id: number; boss: {name: string; hp_max: number; lives: number}; questions: QuestionPayload[]};
        setFight(data);
        setHp(data.boss.hp_max);
        setLives(data.boss.lives);
        askedAt.current = Date.now();
      })
      .catch((error: Error) => toast('error', 'Boss unavailable', error.message));
  }, [bossKey, toast]);

  const question = fight?.questions[index];

  const strike = async (label: string) => {
    if (!fight || !question || picked) return;
    setPicked(label);
    try {
      const result = await api.arena.answerBoss({
        run_id: fight.run_id,
        question_id: question.id,
        selected: label,
        elapsed_ms: Date.now() - askedAt.current,
        combo,
      });
      const data = result as unknown as {correct: boolean; damage: number; crit: boolean; combo: number; hp_left: number; lives: number; finished: boolean; won?: boolean; rewards?: unknown[]};
      setHp(data.hp_left);
      setCombo(data.combo);
      setLives(data.lives);
      setDamage((value) => value + data.damage);
      setFeedback({correct: data.correct, damage: data.damage, crit: data.crit});
      if (data.correct) {
        sfx.play('correct');
        HAPTICS.correct();
      } else {
        sfx.play('wrong');
        HAPTICS.wrong();
      }
      if (data.finished) {
        setOver({won: Boolean(data.won), rewards: data.rewards});
        if (data.rewards?.length) pushRewards(data.rewards as never);
      }
    } catch (error) {
      setPicked(null);
      toast('error', 'Attack failed', (error as Error).message);
    }
  };

  if (over) {
    return (
      <Card className="p-5 text-center">
        <div className={`mx-auto grid size-16 place-items-center rounded-3xl ${over.won ? 'brand-gradient' : 'bg-gradient-to-br from-flare-600 to-nova-700'} text-white`}>
          {over.won ? <Trophy className="size-7" /> : <Skull className="size-7" />}
        </div>
        <h3 className="mt-3 text-lg font-black text-mist-50">{over.won ? 'Boss defeated!' : 'The boss survived'}</h3>
        <p className="mt-1 text-[0.84rem] font-medium text-mist-500">{damage} total damage · best combo {combo}x</p>
        <div className="mt-4 flex justify-center gap-2">
          <Button variant="primary" onClick={onExit}>Back to bosses</Button>
        </div>
      </Card>
    );
  }

  if (!fight || !question) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  return (
    <div className="grid gap-3">
      <Card className="relative overflow-hidden p-4">
        <div className="pointer-events-none absolute -top-20 -right-16 size-44 rounded-full bg-rose-600/18 blur-3xl" />
        <div className="relative flex items-center gap-2">
          <Skull className="size-4 text-rose-300" />
          <h3 className="min-w-0 truncate text-[0.95rem] font-black text-mist-50">{fight.boss.name}</h3>
          <Chip className="ml-auto border-white/12 bg-white/6 text-mist-300" icon={<Swords className="size-3.5" />}>
            {combo > 1 ? `${combo}x combo` : 'combo —'}
          </Chip>
        </div>
        <div className="relative mt-3">
          <div className="flex items-center justify-between text-[0.72rem] font-bold text-mist-400">
            <span>Boss HP</span>
            <span>
              {Math.max(0, hp)}/{fight.boss.hp_max}
            </span>
          </div>
          <div className="mt-1 h-3 w-full overflow-hidden rounded-full bg-ink-800">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-rose-500 to-amber-400"
              animate={{width: `${Math.max(0, (hp / Math.max(fight.boss.hp_max, 1)) * 100)}%`}}
              transition={{type: 'spring', stiffness: 220, damping: 26}}
            />
          </div>
        </div>
        <div className="relative mt-3 flex flex-wrap gap-2">
          <Chip className="border-gold-500/25 bg-gold-500/10 text-gold-200" icon={<Zap className="size-3.5" />}>{damage} damage</Chip>
          {fight.boss.lives > 0 && (
            <Chip className="border-rose-500/25 bg-rose-500/10 text-rose-200" icon={<Heart className="size-3.5" />}>
              {Math.max(0, lives)} lives
            </Chip>
          )}
          <Chip className="ml-auto border-white/12 bg-white/6 text-mist-400">
            {index + 1}/{fight.questions.length}
          </Chip>
        </div>
      </Card>

      <Card className="p-4 sm:p-5">
        <p className="text-[0.98rem] leading-relaxed font-extrabold text-mist-50">{question.text}</p>
        <div className="mt-4 grid gap-2">
          {question.display_order.map((key, position) => {
            const label = 'ABCD'[position] ?? '';
            return (
              <OptionButton
                key={key}
                label={label}
                text={question.options[label] ?? ''}
                state={feedback && feedback.correct && picked === label ? 'correct' : feedback && !feedback.correct && picked === label ? 'wrong' : 'idle'}
                hidden={false}
                disabled={Boolean(picked)}
                onClick={() => void strike(label)}
              />
            );
          })}
        </div>
        <AnimatePresence>
          {feedback && (
            <motion.p
              initial={{opacity: 0, y: 22, scale: 0.9}}
              animate={{opacity: 1, y: 0, scale: 1}}
              exit={{opacity: 0}}
              className={`mt-4 text-center text-[1.05rem] font-black ${feedback.correct ? 'text-mint-300' : 'text-rose-300'}`}
            >
              {feedback.correct ? `${feedback.crit ? 'CRITICAL! ' : ''}−${feedback.damage} HP` : 'The boss heals a little…'}
            </motion.p>
          )}
        </AnimatePresence>
      </Card>

      <div className="flex gap-2">
        {feedback ? (
          <Button
            variant="primary"
            className="flex-1"
            onClick={() => {
              setFeedback(null);
              setPicked(null);
              setIndex((value) => value + 1);
              askedAt.current = Date.now();
            }}
          >
            Next attack
          </Button>
        ) : (
          <p className="flex-1 text-center text-[0.78rem] font-semibold text-mist-500">
            Correct answers deal damage — answer inside 5 seconds for a critical hit.
          </p>
        )}
      </div>
    </div>
  );
}

/* --------------------------------------------------------------------- panel */
export default function PracticePanel() {
  const {toast} = useSession();
  const [tab, setTab] = useState<'practice' | 'boss'>('practice');
  const [modes, setModes] = useState<{modes: ModeRow[]; powerups: Powerup[]} | null>(null);
  const [bossHome, setBossHome] = useState<Record<string, unknown> | null>(null);
  const [history, setHistory] = useState<Record<string, unknown> | null>(null);
  const [running, setRunning] = useState<{mode: string; label: string} | null>(null);
  const [fighting, setFighting] = useState<string | null>(null);

  useEffect(() => {
    api.arena.practiceModes().then((payload) => setModes(payload as unknown as {modes: ModeRow[]; powerups: Powerup[]})).catch((error: Error) => toast('error', 'Practice unavailable', error.message));
    api.arena.bossHome().then(setBossHome).catch(() => setBossHome(null));
    api.arena.practiceHistory().then(setHistory).catch(() => setHistory(null));
  }, [toast]);

  const bosses = useMemo(() => (bossHome?.bosses as {key: string; name: string; hp_per_question: number; lives: number; cycle: string}[] | undefined) ?? [], [bossHome]);
  const community = bossHome?.community as {name: string; hp_max: number; hp_left: number; percent: number; contributions: number; defeated: boolean} | undefined;

  if (running) {
    return <PracticeRun mode={running.mode} label={running.label} onExit={() => { setRunning(null); api.arena.practiceHistory().then(setHistory).catch(() => null); }} />;
  }
  if (fighting) {
    return <BossFight bossKey={fighting} onExit={() => { setFighting(null); api.arena.bossHome().then(setBossHome).catch(() => null); }} />;
  }

  return (
    <div className="grid gap-4">
      <Segmented
        value={tab}
        onChange={setTab}
        options={[
          {value: 'practice', label: 'Practice', icon: Gauge},
          {value: 'boss', label: 'Boss battles', icon: Skull},
        ]}
      />

      {tab === 'practice' && (
        <>
          <div className="grid gap-3">
            <SectionHeading title="Practice modes" subtitle="Sprints, survival runs and daily challenges." icon={<Play className="size-4" />} />
            {!modes && <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3"><Skeleton className="h-24 w-full" /><Skeleton className="h-24 w-full" /></div>}
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {modes?.modes.map((mode) => (
                <button
                  key={mode.key}
                  onClick={() => setRunning({mode: mode.key, label: mode.label})}
                  className="rounded-2xl border border-white/10 bg-ink-900/60 p-3 text-left transition-colors hover:border-nova-400/35 active:scale-[0.99]"
                >
                  <span className="flex items-center justify-between gap-2">
                    <span className="text-[0.86rem] font-extrabold text-mist-100">{mode.label}</span>
                    {mode.best > 0 && <span className="text-[0.68rem] font-bold text-gold-300">PB {mode.best}</span>}
                  </span>
                  <span className="mt-1 flex flex-wrap gap-1.5 text-[0.68rem] font-semibold text-mist-500">
                    <span>{mode.size} questions</span>
                    {mode.lives > 0 && <span>· {mode.lives} lives</span>}
                    {mode.seconds > 0 && <span>· {mode.seconds}s</span>}
                    <span>· {mode.xp} XP/q</span>
                  </span>
                </button>
              ))}
            </div>
          </div>

          {history && (
            <Card className="p-4">
              <SectionHeading title="Your runs" subtitle="Personal bests and recent history" icon={<Trophy className="size-4" />} />
              <div className="mt-3 flex flex-wrap gap-2">
                <Chip className="border-white/12 bg-white/6 text-mist-300">{String((history.stats as Record<string, number>)?.runs ?? 0)} runs</Chip>
                <Chip className="border-mint-500/25 bg-mint-500/10 text-mint-200">{String((history.stats as Record<string, number>)?.accuracy ?? 0)}% accuracy</Chip>
                <Chip className="border-gold-500/25 bg-gold-500/10 text-gold-200">best streak {String((history.stats as Record<string, number>)?.best_streak ?? 0)}</Chip>
                <Chip className="border-nova-500/25 bg-nova-500/10 text-nova-200">{String((history.stats as Record<string, number>)?.days_played ?? 0)} days played</Chip>
              </div>
              <ul className="mt-3 grid gap-1.5">
                {((history.runs as Record<string, unknown>[]) ?? []).slice(0, 6).map((row) => (
                  <li key={String(row.id)} className="flex items-center gap-2 rounded-xl border border-white/8 bg-ink-900/50 px-3 py-2">
                    <span className="min-w-0 flex-1 truncate text-[0.8rem] font-bold text-mist-200">{String(row.label ?? row.mode)}</span>
                    <span className="text-[0.74rem] font-semibold text-mist-500">{String(row.correct)}/{String(row.total)}</span>
                    <span className="text-[0.74rem] font-black text-gold-300">{String(row.score)}</span>
                    {Boolean(row.perfect) && <Chip className="border-mint-500/30 bg-mint-500/12 text-mint-200">perfect</Chip>}
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}

      {tab === 'boss' && (
        <>
          {community && (
            <Card className="relative overflow-hidden p-4">
              <div className="pointer-events-none absolute -top-20 -right-14 size-44 rounded-full bg-rose-600/18 blur-3xl" />
              <div className="relative flex items-center gap-2">
                <Skull className="size-4 text-rose-300" />
                <h3 className="text-[0.95rem] font-black text-mist-50">{community.name}</h3>
                <Chip className="ml-auto border-white/12 bg-white/6 text-mist-300">{community.contributions} hits</Chip>
              </div>
              <ProgressBar value={community.percent} className="mt-3" />
              <p className="mt-1.5 text-[0.76rem] font-semibold text-mist-500">
                {formatHp(community.hp_left)} HP left of {formatHp(community.hp_max)} — every player’s damage counts.
                {community.defeated ? ' Defeated!' : ''}
              </p>
              <Button variant="primary" className="mt-3" onClick={() => setFighting('community')}>Join the raid</Button>
            </Card>
          )}

          <div className="grid gap-2 sm:grid-cols-2">
            {!bosses.length && <Skeleton className="h-28 w-full" />}
            {bosses.map((boss) => (
              <Card key={boss.key} className="flex h-full flex-col p-4">
                <div className="flex items-start gap-2">
                  <div className="grid size-10 shrink-0 place-items-center rounded-2xl border border-rose-500/25 bg-rose-500/12 text-rose-200">
                    <Skull className="size-5" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-[0.9rem] font-extrabold text-mist-50">{boss.name}</h3>
                    <p className="text-[0.72rem] font-semibold text-mist-500">
                      {boss.hp_per_question} HP per hit · {boss.lives > 0 ? `${boss.lives} lives` : 'no life limit'}
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <Chip className="border-white/12 bg-white/6 text-mist-400">{boss.cycle}</Chip>
                  {(boss.key === 'daily_boss' || boss.key === 'weekly_boss') && (
                    <Chip className="border-amber-500/25 bg-amber-500/10 text-amber-200" icon={<AlertTriangle className="size-3" />}>one attempt</Chip>
                  )}
                </div>
                <Button variant="primary" size="sm" className="mt-3 self-start" onClick={() => setFighting(boss.key)}>
                  Fight
                </Button>
              </Card>
            ))}
          </div>

          {Boolean(bossHome?.weekly) && (
            <Card className="p-4">
              <SectionHeading title="Weekly boss ladder" subtitle="Highest damage this cycle" icon={<Trophy className="size-4" />} />
              <ul className="mt-3 grid gap-1.5">
                {(((bossHome?.weekly as Record<string, unknown>)?.leaderboard as {name: string; damage: number}[]) ?? []).map((row, position) => (
                  <li key={`${row.name}-${position}`} className="flex items-center gap-2 rounded-xl border border-white/8 bg-ink-900/50 px-3 py-2">
                    <span className="w-6 text-[0.76rem] font-black text-mist-500">#{position + 1}</span>
                    <span className="min-w-0 flex-1 truncate text-[0.82rem] font-bold text-mist-200">{row.name}</span>
                    <span className="text-[0.78rem] font-black text-gold-300">{row.damage}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}

      {tab === 'practice' && modes && !modes.modes.length && (
        <EmptyState icon={<Gauge className="size-5" />} title="No questions available" detail="An admin needs to publish questions before practice modes open up." />
      )}
    </div>
  );
}

function formatHp(value: number): string {
  return value >= 1000 ? `${(value / 1000).toFixed(1)}k` : String(Math.round(value));
}
